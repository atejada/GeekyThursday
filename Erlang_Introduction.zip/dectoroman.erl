-module(dectoroman).
-export([showRomans/1]).

showRomans(Number) when is_integer(Number) ->
	Roman_Nums = [{1000,"M"},{900,"CM"},{500,"D"},{400,"CD"},
				  {100,"C"},{90,"XC"},{50,"L"},{40,"XL"},
				  {10,"X"},{9,"IX"},{5,"V"},{4,"IV"},{1,"I"}],
	showRomans(Number,Roman_Nums,1,"").
	
showRomans(0,_,_,Acc) ->
	io:format("~s~n",[Acc]);
showRomans(Number,Roman_Nums,Counter,Acc) ->
	case Number >= element(1,lists:nth(Counter,Roman_Nums)) of
		true -> showRomans(Number - element(1,lists:nth(Counter,Roman_Nums)),Roman_Nums, 
						   Counter, Acc ++ element(2,lists:nth(Counter,Roman_Nums)));
		false -> showRomans(Number,Roman_Nums,Counter + 1,Acc)
	end.
