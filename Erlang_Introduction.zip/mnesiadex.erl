-module(mnesiadex).
-include_lib("stdlib/include/qlc.hrl").
-export([initialize/0,start/0,stop/0,add_album/3,remove_album/1,show_albums/0,show_artist/1]).
-record(music, {id, artist, album}).

initialize() ->
	mnesia:create_schema([node()]),
    mnesia:start(),
    mnesia:create_table(music, [{attributes,record_info(fields, music)},{disc_only_copies,[node()]}]),mnesia:stop().
    
start() ->
    mnesia:start(),
    mnesia:wait_for_tables([music], 20000).
    
stop() ->
    mnesia:stop().
    
do(Q) ->
    F = fun() -> qlc:e(Q) end,
    {atomic, Val} = mnesia:transaction(F), Val.
    
add_album(Id, Artist, Album) ->
    Row = #music{id=Id, artist=Artist, album=Album},
    F = fun() ->
        mnesia:write(Row)
    end,
    mnesia:transaction(F).
    
remove_album(Id) ->
    Oid = {music, Id},
    F = fun() ->
        mnesia:delete(Oid)
    end,
    mnesia:transaction(F).

show_albums() ->
    do(qlc:q([{X#music.album,X#music.artist} || X <- mnesia:table(music)])).
    
show_artist(Artist) ->
    do(qlc:q([X#music.album || X <- mnesia:table(music),X#music.artist =:= Artist])).
        
