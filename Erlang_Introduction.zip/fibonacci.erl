-module(fibonacci).
-export([fib/1]).

fib(Number) ->
    fib(Number,0,1,"").
fib(1,_,_,Acc) ->
    io:format("~p~n",["0 1 " ++ Acc]);
fib(Number,A,B,Acc) when A > 0 ->
    fib(Number - 1, A + B, A, Acc ++ integer_to_list(A + B) ++ " ");            
fib(Number,A,B,Acc) ->
    fib(Number - 1, A + B, B, Acc ++ integer_to_list(A + B) ++ " "). 
