-module(numbers).
-export([num/1,num/2]).

num(Number) ->
    io:format("This is your number ~p~n",[Number]).  
num(Number1,Number2) ->
    io:format("This is the sum of two numbers ~p~n", [Number1 + Number2]).
