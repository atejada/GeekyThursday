-module(greetings).
-export([greet/2]).

greet(male, Name) ->
    io:format("Good morning Mr. ~s~n", [Name]);
greet(female, Name) ->
    io:format("Good morning Mrs. ~s~n", [Name]);
greet(_, Name) ->
    io:format("Good morning ???. ~s~n", [Name]).
