-module(concurrent).
-export([run/1]).

proc1(N) when N < 1000 ->
	proc1(N+1);
proc1(N) -> 
	io:format("Process 1: ~p~n",[N]),
	io:format("Sleeping~n"),
	timer:sleep(3000).

proc2(N) when N < 1000 ->
	proc2(N+1);
proc2(N) -> 
	io:format("Process 2: ~p~n",[N]).
	
run(N) ->
	proc1(N),
	proc2(N),
	proc1(N),
	proc2(N),
	spawn(fun() -> proc1(N) end),
	spawn(fun() -> proc2(N) end).
