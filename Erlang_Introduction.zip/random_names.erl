-module(random_names).
-export([show_names/0, run_names/0]).
   
show_names() ->
	Names = ["Anne","Gigi","Blag","Juergen","Marek","Ingo",
			"Lars","Julia","Danielle","Rocky","Julien",
			"Uwe","Myles","Mike","Steven","Fanny"],
	Last_Names = ["Hardy","Read","Tejada","Schmerder",
				  "Kowalkiewicz","Sauerzapf","Karg", 
                  "Satsuta","Keene","Ongkowidjojo",
                  "Vayssiere","Kylau","Fenlon",
                  "Flynn","Taylor","Tan"],
    generate_names(Names,Last_Names).
 
generate_names(Names,Last_Names) ->
	_ = [ lists:nth(rand:uniform(16),Names) ++ " " ++ 
	      lists:nth(rand:uniform(16),Last_Names) ++ 
	      "\n" || _ <-lists:seq(1,100000) ],
	io:format("Done").
	%--halt(0).
	
run_names() ->
    {Time, _} = timer:tc(random_names, show_names,[]),
    RunTime = Time /1000000,
    io:format("\n~p~n",[RunTime]).
