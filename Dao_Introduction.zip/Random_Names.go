package main

import ( "fmt";"math/rand";"time" )

func main() {

    start := time.Now()
    
    names := [16]string{"Anne","Gigi","Blag","Juergen",
                        "Marek","Ingo","Lars","Julia",
                        "Danielle","Rocky","Julien",
                        "Uwe","Myles","Mike",
                        "Steven","Fanny"}
                        
    last_names := [16]string{"Hardy","Read","Tejada",
                             "Schmerder","Kowalkiewicz",
                             "Saurzapf","Karg","Satsuta",
                             "Keene","Ongkowidjojo",
                             "Vayssiere","Kaylu","Fenlon",
                             "Flynn","Taylor","Tan"}
                             
    full_names := make([]string, 100000)
    i := 1
    for i < 100000 {
        full_names[i] = names[rand.Intn(15)] + last_names[rand.Intn(15)]
        i++
    }
    
    elapsed := time.Since(start)
    fmt.Println("Time: ", elapsed.Seconds())
    fmt.Println(len(full_names), " names generated")
}                                
