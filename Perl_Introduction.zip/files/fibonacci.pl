#!/usr/bin/perl
use strict;
use warnings;
use diagnostics;

sub fib {
	my ($num,$a,$b) = @_;
	my $result = q{};
	if ($a>0 && $num>1){
		$result = $result . ($a+$b) . q{ } . fib($num-1,$a+$b,$a)
	}elsif($a == 0){
		$result = $a . q{ } . $b . q{ } . ($a+$b) . q{ } . fib($num-1,$a+$b,$b)
	}
	return $result
}

print "Enter a number: ";
my $num = <>;

print(fib($num,0,1),"\n");
