#!/usr/bin/perl
use strict;
use warnings;
use diagnostics;
use Time::HiRes qw(time);

my $start_run = time;

my @names = qw(
Anne Gigi Blag Juergen Marek Ingo Lars Julia
Danielle Rocky Julien Uwe Myles Mike Steven Fanny
);

my @last_names = qw(
Hardy Read Tejada Schmerder Kowalkiewicz Sauerzapf
Karg Satsuta Keene Ongkowidjojo Vayssiere Kylau
Fenlon Flynn Taylor Tan
);

my @full_names;
my $full_name;

foreach (1..1000000){
	$full_name = $names[0 + int rand(16)] . q{ } . $last_names[0 + int rand(16)];
	push @full_names, $full_name;
}

my $end_run = time;
print "Time: ", $end_run - $start_run, "\n";
print scalar @full_names, " names generated\n";
