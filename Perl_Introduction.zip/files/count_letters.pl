#!/usr/bin/perl
use strict;
use warnings;
use diagnostics;

open(my $fh, "<", "readme.txt") or die "Can't open readme.txt: $!";

my $line = <$fh>;

my @letters = split //, $line;

my %counter;

foreach my $letter (@letters){
	$counter{$letter} = ($counter{$letter} or 0) + 1;
}

while(my ($key, $value) = each %counter){
	print "$key => $value\n";
}
close $fh;

