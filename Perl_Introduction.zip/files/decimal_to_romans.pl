#!/usr/bin/perl
use strict;
use warnings;
use diagnostics;

my %roman_table = (
'1000' => 'M', '900' => 'CM', '500' => 'D',
'400' => 'CD', '100' => 'C', '90' => 'XC',
'50' => 'L', '40' => 'XL', '10' => 'X',
'9' => 'IX', '5' => 'V', '4' => 'IV', '1' => 'I'
);

sub roman_number{
	my $number = shift; my $result;
	my @sorted = sort { $b <=> $a } keys %roman_table;
	until($number == 0){
		foreach my $value (@sorted){
			if($number >= $value){
				$result = $result . $roman_table{$value};
				$number -= $value;
				last;
			}
		}
	}
	return $result;
}

print "Enter a number: ";
my $num = <>;
my $result = roman_number($num);
print "$result\n";
