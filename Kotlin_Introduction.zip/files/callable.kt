package callable

fun add(a: Int, b: Int): Int = a + b
fun multi(a:Int, b: Int): Int = a * b

fun operation(a: Int, b: Int, func:(a: Int, b: Int) -> Int){
	val result = func(a, b)
	println("$result")
}

fun main(args: Array<String>) {
	operation(10, 10, ::add)
	operation(10, 10, ::multi)
}
