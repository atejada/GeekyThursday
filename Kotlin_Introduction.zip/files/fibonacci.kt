package Fibonacci

fun fib(num: Int, a: Int, b: Int): String {
	var result: String = ""
	if(a > 0 && num > 1) {
		result = result + (a+b) + " " + fib(num-1,a+b,a)
	}else if (a == 0) {
		result = a.toString() + " " + b + " " + (a+b) + " " + fib(num-1,a+b,b)
	}
	return result
}

fun main(args: Array<String>) {
	if (args.size == 0) {
      println("Please provide a number...")
      return
    }
   val num: Int = args[0].toInt()
   println(fib(num,0,1))
}
