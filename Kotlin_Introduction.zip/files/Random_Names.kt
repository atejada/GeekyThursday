package Random_Names

import java.util.Random

fun main(args: Array<String>) {
	val names = arrayOf("Anne","Gigi","Blag","Juergen","Marek","Ingo",
						"Lars","Julia", "Danielle","Rocky","Julien",
						"Uwe","Myles","Mike","Steven","Fanny")
	val last_names = arrayOf("Hardy","Read","Tejada","Schmerder",
							 "Kowalkiewicz","Sauerzapf","Karg",
							 "Satsuta","Keene","Ongkowidjojo",
						     "Vayssiere","Kylau","Fenlon",
						     "Flynn","Taylor","Tan")
	var full_names = Array(100000, { i -> i.toString() })
	val r = Random()
	for(i in 0..99999){
		var x = r.nextInt(16)
		var y = r.nextInt(16)
		full_names[i] = names[x] + " " + last_names[y]
	}
}
