package Decimal_To_Roman

fun roman_number(num: Int, Romans: Array<Pair<Int,String>>, Counter: Int, result: String){
	val roman = Romans[Counter].first
	if(num >= roman){
		roman_number(num - roman, Romans, Counter, result + Romans[Counter].second)
	}else if (num < roman && num > 0){
		roman_number(num, Romans, Counter + 1, result)
	}else if (num <= 0){
		println(result)
	}
}

fun main(args: Array<String>) {
	if (args.size == 0) {
      println("Please provide a number...")
      return
    }
    val num: Int = args[0].toInt()
	val Romans = arrayOf(Pair(1000,"M"), Pair(900,"CM"),
						 Pair(500,"D"), Pair(400,"CD"),
						 Pair(100,"C"), Pair(90,"CX"),
						 Pair(50,"L"), Pair(40,"XL"),
						 Pair(10,"X"), Pair(9,"IX"),
						 Pair(5,"V"), Pair(4,"IV"),
						 Pair(1,"I"))
	roman_number(num, Romans, 0, "")
}
