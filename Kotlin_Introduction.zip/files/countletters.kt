package countletters

import java.io.File

fun main(args: Array<String>) {
	val line = File("readme.txt").readText(charset = Charsets.UTF_8)
	val len = line.length
	var letters = arrayListOf(Pair("",0))
	letters.remove(Pair("",0))
	var flag: Boolean
	for(i in 0..len - 1){
		flag = false
		if(letters.size > 0){
			for(j in 0..letters.size - 1){
				if(letters[j].first == line[i].toString()){
					letters.set(j,Pair(line[i].toString(),letters[j].second + 1))
					flag = true
					break
				}
			}
			if(flag == false){
				letters.add(Pair(line[i].toString(),1))
			}
		}else{
			letters.add(Pair(line[i].toString(),1))
		}
	}
	for((k,v) in letters){
		println("$k --> $v")
	}
}
