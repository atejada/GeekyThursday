This is a file that we are going to read using Arturo
