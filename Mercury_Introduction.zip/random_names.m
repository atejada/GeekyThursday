:- module random_names.
:- interface.
:- import_module io.

:- pred main(io::di, io::uo) is det.

:- implementation.
:- import_module int, random, array, list, string.

:- pred time(int::out, io::di, io::uo) is det.
 
:- pragma foreign_decl("C", "#include <time.h>").
:- pragma foreign_proc("C", time(Int::out, _IO0::di, _IO1::uo),
                       [will_not_call_mercury, promise_pure],
                       "Int = time(NULL);").

:- pred generate_random_names(array(string)::in, array(string)::in, int::in, array(string)::in, array(string)::out, io::di, io::uo) is det.

generate_random_names(Names, Last_Names, Ctr, Full_NamesIn, Full_Names, !IO) :-
(
	(
		if Ctr =< 100000 then
			time(Time, !IO),
			random.init(Time, Rand),
			random.random(0, 15, N1, Rand, _),
			random.random(0, 15, N2, Rand, _),
			Name = elem(N1, Names),
			LastName = elem(N2, Last_Names),
			Full_Name = Name ++ " " ++ LastName,
			UpdatedResult = append(Full_NamesIn, array([Full_Name])),
			generate_random_names(Names, Last_Names, Ctr + 1, UpdatedResult, Full_Names, !IO)
		else
			Full_Names = Full_NamesIn
	)		
).
	
main(!IO) :-
	Names = array(["Anne","Gigi","Blag","Juergen","Marek","Ingo","Lars",
	               "Julia", "Danielle","Rocky","Julien","Uwe","Myles",
	               "Mike","Steven", "Fanny"]),
    Last_Names = array(["Hardy","Read","Tejada","Schmerder","Kowalkiewicz",       
						"Sauerzapf","Karg","Satsuta","Keene","Ongkowidjojo",
						"Vayssiere","Kylau","Fenlon","Flynn","Taylor","Tan"]),
	Full_NamesIn = array([]),
    generate_random_names(Names, Last_Names, 0, Full_NamesIn, Full_Names, !IO),
    io.write("Done", !IO).
