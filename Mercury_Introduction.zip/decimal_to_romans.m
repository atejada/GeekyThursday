:- module decimal_to_romans.
:- interface.
:- import_module io.

:- pred main(io::di, io::uo) is det.

:- implementation.
:- import_module list, string, int, array, char.

:- pred get_romans(int::in, int::in, list.list(string)::out ) is det.

get_romans(Num, Ctr, Response) :-
( 
    Roman_Nums = array([array(["1000","M"]), array(["900","CM"]),
						array(["500","D"]), array(["400","CD"]),
						array(["100","C"]), array(["90","XC"]),
						array(["50","L"]), array(["40","XL"]),
						array(["10","X"]), array(["9","IX"]),
						array(["5","V"]), array(["4","IV"]),
						array(["1","I"])]),
		Line = elem(Ctr, Roman_Nums),
		Key = elem(0, Line),
		IKey = det_to_int(Key),
		(if Num >= IKey then
			Value = elem(1, Line),
			get_romans(Num - IKey, Ctr, Result),
			Response = [Value] ++ Result
		 else if Num < IKey, Num > 0 then
			get_romans(Num, Ctr + 1, Result),
			Response = Result
		 else
			Response = [] )
).

main(!IO) :-
	io.write_string("Enter a number: ",!IO),
	io.read_line_as_string(Result, !IO),
	(	if
			Result = ok(String),
			SNum = string.strip(String),
			Num = det_to_int(SNum),
			get_romans(Num, 0, Response)
		then
			io.write_string(string.join_list("", Response), !IO)
		else
			io.write_string("Not a number...",!IO)
	).
