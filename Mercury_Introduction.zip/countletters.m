:- module countletters.
:- interface.
:- import_module io.

:- pred main(io::di, io::uo) is det.

:- implementation.
:- import_module string, list, array, char, int.

:- pred search_array(string::in, array(array(string))::in, int::in, int::out) is det.

:- pred count_letters(list(char)::in, array(array(string))::in, array(array(string))::out ) is det.

:- pred print_counter(list(array(string))::in, io::di, io::uo) is det.

print_counter(LstResult, !IO) :-
(	
	if Tail = tail(LstResult)
		then
			Head = det_head(LstResult),
			Letter = elem(0, Head),
			Counter = elem(1, Head),
			io.write(Letter,!IO),
			io.write_string("-->",!IO),
			io.write(Counter,!IO),
			io.write_string("\n",!IO),
			print_counter(Tail, !IO)
	else
		io.write_string("",!IO)
).

search_array(KeyValue, LstResult, Ctr, Result) :-
(
	size(LstResult, LenResult),
	(
		if Ctr < LenResult then
			Line = elem(Ctr, LstResult),
			Key = elem(0, Line),
			(
				if Key = KeyValue 
				then Result = Ctr
				else search_array(KeyValue, LstResult, Ctr + 1, Result)
			)
		else
			Result = -1
	)
).

count_letters(LstContents, LstResultIn ,LstResult) :-
(
	(
		if Tail = tail(LstContents)
		then
			Head = det_head(LstContents),
			char_to_string(Head, Letter),
			search_array(Letter, LstResultIn, 0, Result),
			(
				if Result >= 0 then
					Line = elem(Result, LstResultIn),
					Value = elem(1, Line),
					(
						if Value \= " " then
							IValue = det_to_int(Value) + 1
						else
							IValue = 1
					),
					SValue = int_to_string(IValue),
					set(1, SValue , Line, UpdatedResult),
					count_letters(Tail, LstResultIn, LstResult)
				else
					UpdatedResult = append(LstResultIn, array([array([Letter,"1"])])),
					count_letters(Tail, UpdatedResult, LstResult)
			)
		else 
			LstResult = LstResultIn
	)
).

main(!IO) :-
	io.open_input("readme.txt", InputRes, !IO),
	(
		InputRes = ok(Input),
		io.read_file_as_string(Input, ReadRes, !IO),
		io.close_input(Input, !IO),
		(
			(
			if
				ReadRes = ok(Contents),
				to_char_list(Contents,LstContents),
				LstResultIn = array([array(["",""])]),
				count_letters(LstContents, LstResultIn, LstResult)
			then
				to_list(LstResult,LstList),
				print_counter(LstList,!IO)
			else
				io.write("Error!", !IO)
			)
		);
		InputRes = error(InputError),
		io.write(InputError, !IO)
	).
	
