:- module fibonacci.
:- interface.
:- import_module io.

:- pred main(io::di, io::uo) is det.

:- implementation.
:- import_module string, int.

:- pred fibo(int::in, int::in, int::in, string::out) is det.

fibo(Num, A, B, Fibs) :-
	(	
		if A = 0 
		then fibo(Num-1,A+B,B,Fib), Fibs = int_to_string(A) ++ " " ++ int_to_string(B) ++ 
		                                   " " ++ int_to_string(A+B) ++ " " ++ Fib
		else if A > 0, Num > 1
		then fibo(Num-1,A+B,A,Fib), Fibs = int_to_string(A+B) ++ " " ++ Fib
		else Fibs = ""
	).
	
main(!IO) :-
	io.write_string("Enter a number: ",!IO),
	io.read_line_as_string(Result, !IO),
	(	if
			Result = ok(String),
			string.to_int(string.strip(String), N)
		then
			fibo(N,0,1,Fibs),
			io.write_string(Fibs,!IO)
		else
			io.write_string("Not a number...",!IO)
	).
