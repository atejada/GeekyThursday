module WebServerFibonacci

Base.eval(Main, :(const UserApp = WebServerFibonacci))

include("genie.jl")

Base.eval(Main, :(const Genie = WebServerFibonacci.Genie))
Base.eval(Main, :(using Genie))

using Genie, Genie.Router, Genie.Renderer, Genie.AppServer

end
