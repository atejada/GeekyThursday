using Genie.Router
using Genie.Renderer
using fibocontroller

route("/fibo") do
	html!(:home, :form)
end

route("/getfibo", fibocontroller.getfibo, method = POST, named = :getfibo_cont)
