module fibocontroller

    using Genie.Router
    using Genie.Renderer

    function getfibo()
        result = ""
        fib = 1
        first = 0
        second = 1

        for i in 1:parse(Int64,(@params(:num)))    
    	   result = result * " " * string(fib)
           fib = first + second
           first = second
           second = fib
        end
    
       html!(:home, :fiboseq, res = result)
    
    end
end
