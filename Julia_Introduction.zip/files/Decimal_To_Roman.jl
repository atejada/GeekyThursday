Roman_Table = Dict(1000=> "M", 900=> "CM", 500=> "D", 400=> "CD",
               100=> "C", 90=> "XC", 50=> "L", 40=> "XL", 
	           10=> "X", 9=> "IX", 5=> "V", 4=> "IV", 1=> "I")

function Roman_Number(number)
	result = ""
	key = sort(collect(keys(Roman_Table)),rev=true)
	while number > 0
	 	for value in key
	 		if number >= value
	      		result *= Roman_Table[value]
        		number -= value
				break
			end
		end
	end
	return result
end

print("Enter a number: "); number = chomp(readline())
result = Roman_Number(parse(Int,number))
println(result)
