start = time()
using DataFrames
using CSV
isdefined(@__MODULE__,:Films) || 
(Films = CSV.read("Films_Table.csv", header=true, nastrings=["","NA"]))
println("Records before clean up: " * string(nrow(Films)))
unique!(Films)
dropmissing!(Films,disallowmissing=true)
Films_Info = DataFrame(Movie_Id=Films[:Movie_Id],Name=Films[:Movie_Name],Release_Date=Films[:Release_Date])
println("Records after clean up: " * string(nrow(Films)))
sort!(Films_Info, [:Release_Date])
CSV.write("Films_Info_Julia.csv", Films_Info)
finish = time()
println("Time: ", finish-start)
println("The file was generated successfully!")
