start.time <- Sys.time()
if(!exists("Films")){
  Films<-read.csv("Films_Table.csv", header=TRUE, 
                   stringsAsFactors=FALSE, colClasses="character", na.strings = "")
}
cat("Records before clean up: ", nrow(Films), "\n")
Films<-unique(Films)
Films<-Films[complete.cases(Films),]
Films_Info<-data.frame(Movie_Id=Films$Movie_Id,Name=Films$Movie_Name,Release_Date=Films$Release_Date)
cat("Records after clean up: ", nrow(Films_Info), "\n")
Films_Info<-Films_Info[order(Films$Release_Date),]
write.csv(Films_Info,"Films_Info_R.csv",row.names=TRUE)
end.time <- Sys.time()
time.taken <- end.time - start.time
cat("Time ", time.taken, "\n")
cat("The file was generated successfully!")
