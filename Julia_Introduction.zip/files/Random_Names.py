import time
import random

start = time.clock()

names=["Anne","Gigi","Blag","Juergen","Marek","Ingo","Lars","Julia",
       "Danielle","Rocky","Julien","Uwe","Myles","Mike", "Steven", "Fanny"]
last_names=["Hardy","Read","Tejada","Schmerder","Kowalkiewicz","Sauerzapf",
            "Karg","Satsuta","Keene","Ongkowidjojo","Vayssiere","Kylau",
            "Fenlon","Flynn","Taylor", "Tan"]

full_names=[]
full_name = ""

for i in range(0,100000):
        full_name = names[random.randrange(0, 16)] + last_names[random.randrange(0, 16)]
        full_names.append(full_name)

print("Time: " + str(time.clock() - start))
print(str(len(full_names)) + " names generated")