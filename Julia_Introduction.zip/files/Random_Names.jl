start = time()

names=["Anne","Gigi","Blag","Juergen","Marek","Ingo","Lars",
       "Julia", "Danielle","Rocky","Julien","Uwe","Myles",
       "Mike","Steven", "Fanny"]

last_names=["Hardy","Read","Tejada","Schmerder","Kowalkiewicz",       
            "Sauerzapf","Karg","Satsuta","Keene","Ongkowidjojo",
            "Vayssiere","Kylau","Fenlon","Flynn","Taylor","Tan"]            
            
full_names=AbstractString[]

full_name = ""
		
for i = 1:100000
  full_name = names[rand(1:16)] * " " * last_names[rand(1:16)]
  push!(full_names,full_name)
end

finish = time()

println("Time: ", finish-start)
println(length(full_names), " names generated")			
			
