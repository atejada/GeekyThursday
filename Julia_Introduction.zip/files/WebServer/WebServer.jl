module WebServer

Base.eval(Main, :(const UserApp = WebServer))

include("genie.jl")

Base.eval(Main, :(const Genie = WebServer.Genie))
Base.eval(Main, :(using Genie))

using Genie, Genie.Router, Genie.Renderer, Genie.AppServer

end
