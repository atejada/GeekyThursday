using Genie.Router
using Genie.Renderer

route("/login") do
	html!(:home, :form)
end

route("/greet_me", method = POST, named = :greet_me) do
	html!(:home, :greetings, name=@params(:name))
end
