using Genie

makedocs()
