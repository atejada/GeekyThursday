using DataFrames
using Gadfly
using CSV
isdefined(@__MODULE__,:Films) || (Films = CSV.read("Films_Info_Julia.csv", header=true, nastrings=["","NA"]))
Years = Dict{String,Int32}()
for film in Films[:Release_Date]
	try
		Years["$film"] += 1
	catch e
		Years["$film"] = 1
	end
end

years = []
count = []
for (k, v) in Years
	push!(years,k)
	push!(count,v)
end


df = DataFrame(Years=[parse(Int64,s) for s = years],Count=count)

plot(df,x="Years",y="Count")
