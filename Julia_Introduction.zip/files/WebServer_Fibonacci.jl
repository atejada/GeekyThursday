using HttpServer

function fibo(number)
	result = ""
	fib = 1
	first = 0
	second = 1
	for i in 1:number
		result = result * " " * string(fib)
		fib = first + second
		first = second
		second = fib
	end
	return result
end

http = HttpHandler() do req::Request, res::Response
	if ismatch(r"^/julia", req.resource)
		out = "<form action='/getfibo' method='post'>"
		out = string(out,"<label for='number'>Enter a number: </label><br/>")
		out = string(out,"<input type='text' name='number'/>")
		out = string(out,"<input type='submit' name='submit' value='Calculate!'/>")
		return Response(out)
	end
	if ismatch(r"^/getfibo", req.resource)
		reqsplit = split(req.data, "&")
		reqsplit = split(string(reqsplit[1]), "=")
		fib = fibo(int(reqsplit[2]))
		out = "The Fibonacci sequence is: "
		out = string(out,fib)
		return Response(out)
	end
end

server = Server(http)
run(server, 8000)
