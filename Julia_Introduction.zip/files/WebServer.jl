using HttpServer

http = HttpHandler() do req::Request, res::Response
	if ismatch(r"^/julia", req.resource)
		out = "<form action='/login' method='post'>"
		out = string(out,"<label for='name'>Enter your name: </label><br/>")
		out = string(out,"<input type='text' name='name'/>")
		out = string(out,"<input type='submit' name='submit' value='Greet Me!'/>")
		return Response(out)
	end
	if ismatch(r"^/login", req.resource)
		reqsplit = split(req.data, "&", !Matched::Bool)
		reqsplit = split(string(reqsplit[1]), "=")
		out = "Hello from Julia, "
		out = string(out,reqsplit[2])
		out = string(out,"!")
		return Response(out)
	end
end

server = Server(http)
run(server, 8000)
