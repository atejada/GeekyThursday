leds = Dict("0" => " _  ,| | ,|_|",
            "1" => "  ,| ,| ",
            "2" => " _  , _| ,|_  ",
		    "3" => "_  ,_| ,_| ",
		    "4" => "    ,|_| ,  | ",
		    "5" => " _  ,|_  , _| ",
		    "6" => " _  ,|_  ,|_| ",
		    "7" => "_   , |  , |  ",
		    "8" => " _  ,|_| ,|_| ",
		    "9" => " _  ,|_| , _| ")

list = ""; line1 = ""; line2 = ""; line3 = "";

print("Enter a number: "); number = chomp(readline())
len = length(number)
for i in 1:len
	list = split(leds[string(number[i])],",")
	global line1 *= list[1]
	global line2 *= list[2]
	global line3 *= list[3]
end

println(line1)
println(line2)
println(line3 * "\n")
