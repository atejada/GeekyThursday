import Foundation;

let start = NSDate();

let names: [String] = [
	"Anne", "Gigi", "Blag", "Juergen", "Marek", "Ingo", "Lars", "Julia",
    "Danielle", "Rocky", "Julien", "Uwe", "Myles", "Mike", "Steven", "Fanny"
];

let last_names: [String] = [
	"Hardy", "Read", "Tejada", "Schmerder", "Kowalkiewicz", "Sauerzapf",
    "Karg", "Satsuta", "Keene", "Ongkowidjojo", "Vayssiere", "Kylau",
    "Fenlon", "Flynn", "Taylor", "Tan"
];

let time = UInt32(NSDate().timeIntervalSinceReferenceDate)
srand(time)

var full_names = [String]();
var full_name:String;

for i in 1...1000000{
	full_name = names[Int(rand()%16)] + " " + last_names[Int(rand()%16)];
	full_names.append(full_name);
}

let elapsed = abs(start.timeIntervalSinceNow);
print("Time: \(elapsed)");
print("\(full_names.count) names generated");
