func fib(num:Int,a:Int,b:Int) -> String{
	var result: String = "";
	if a > 0 && num > 1{
		result = result + String(a + b) + " " + 
		         fib(num: (num - 1), a: (a + b), b: a);
	}else if a == 0{
		result = String(a) + " " + String(b) + " " + 
		         String(a + b) + " " + 
		         fib(num: (num - 1), a: (a + b), b: b);
	}
	return result;
}

print("Enter a number: ",terminator:"");
let number = Int(readLine(strippingNewline: true)!);

print(fib(num: number!, a: 0, b: 1));
