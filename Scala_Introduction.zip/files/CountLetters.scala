import scala.io.Source
var lines = ""
for(line <- Source.fromFile("readme.txt").getLines())
lines = line
var letters = Map("" -> 0)
var counter = 0
for(line <- 0 to (lines.length - 1)){
	if(letters.contains(lines(line).toString)){
		counter = letters(lines(line).toString) + 1
		letters -= lines(line).toString
		letters += (lines(line).toString -> counter)
	}else{
		letters += (lines(line).toString -> 1)
	}
}
letters -= ""

for(pairs <- letters) {println(pairs)}
