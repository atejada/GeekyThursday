import scala.collection.mutable.ListBuffer

var list = time{
	val names = List("Anne", "Gigi", "Blag", "Juergen", "Marek", "Ingo", "Lars", "Julia", 
				     "Danielle", "Rocky", "Julien", "Uwe", "Myles", "Mike", "Steven", "Fanny")
                 
	val last_names = List("Hardy", "Read", "Tejada", "Schmerder", "Kowalkiewicz", "Sauerzapf", 
                          "Karg", "Satsuta", "Keene", "Ongkowidjojo", "Vayssiere", "Kylau", 
                          "Fenlon", "Flynn", "Taylor", "Tan")

	var full_names = new ListBuffer[String]()
	val r = scala.util.Random
	for(i <- 0 to 100000){
		full_names += (names(r.nextInt(16)) + " " + last_names(r.nextInt(16)))
	}
}

print(list)

def time[R](block: => R): R = {  
    val t0 = System.nanoTime()
    val result = block
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0) + "ns")
    result
}
