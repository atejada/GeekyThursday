import scala.util.{Try, Success, Failure}

def fib(num: Int, a: Int, b: Int): String = {
	a > 0 && num > 1 match {
		case true => (a + b).toString + " " + fib((num - 1), (a + b), a)
		case false => a == 0 match {
			case true => a.toString + " " + b.toString + " " + (a + b).toString + " " + fib((num - 1), (a + b), b)
			case false => ""
		}
	}
}

val num = scala.io.StdIn.readLine("Please enter a Number: ")
if(Try(num.toDouble).isSuccess){
	print(fib(num.toInt,0,1))
}else{
	println("Please enter a number!")
}
