import scala.collection.immutable.ListMap
import scala.util.Try

val roman_table = Map(1000 -> "M", 900 -> "CM", 500 -> "D",
                      400 -> "CD", 100 -> "C", 90 -> "XC",
                      50 -> "L", 40 -> "XL", 10 -> "X",
                      9 -> "IX", 5 -> "V", 4 -> "IV", 1 -> "I")

var orderRoman_Table = ListMap(roman_table.toSeq.sortWith(_._1 > _._1):_*)
var keys = orderRoman_Table.keySet.toList

def show_romans(num: Int, ctr: Int): String = {
	val roman = keys(ctr)
	num > roman match{
		case true => roman_table(roman) + show_romans((num - roman), ctr)
		case false => num < roman && num > 0 match{
			case true => show_romans(num, (ctr + 1))
			case false => "" + roman_table(roman)
		}
	}
}

try{
	print("Enter a number: ")
	val num = scala.io.StdIn.readInt()
	println(show_romans(num, 0))
}catch{
	case e: NumberFormatException => println("Please enter a number!")
}
