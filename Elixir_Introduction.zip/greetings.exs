defmodule Greetings do
  def greet(:male, name) do
    IO.puts("Good morning Mr. #{name}")
  end
  
  def greet(:female, name) do
    IO.puts("Good morning Mrs. #{name}")
  end
  
  def greet(_, name) do
    IO.puts("Good morning ??? #{name}")
  end  
end
