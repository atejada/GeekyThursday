defmodule DecToRomans do
  def showRomans(number) when is_number(number) do
    romanNums = [{1000,"M"},{900,"CM"},{500,"D"},
                 {400,"CD"},{100,"C"},{90,"XC"},
                 {50,"L"},{40,"XL"},{10,"X"},
                 {9,"IX"},{5,"V"},{4,"IV"},{1,"I"}]
    showRomans(number,romanNums,0,"") 
  end
  
  def showRomans(0,_,_,acc) do
    IO.puts(acc)
  end
  
  def showRomans(number, romanNums, counter, acc) do
    key = elem(Enum.at(romanNums, counter), 0)
    value = elem(Enum.at(romanNums, counter), 1)
    case number >= key do
      true -> showRomans(number - key, romanNums, counter, acc <> value)
      false -> showRomans(number, romanNums, counter + 1, acc)
    end
  end
end
