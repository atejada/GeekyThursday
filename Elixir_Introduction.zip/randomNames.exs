defmodule RandomNames do
  def show_names() do
  
    names = ["Anne","Gigi","Blag","Juergen",
	         "Marek","Ingo","Lars","Julia",
	         "Danielle","Rocky","Julien",
	         "Uwe","Myles","Mike","Steven",
             "Fanny"]
             
    last_names = ["Hardy","Read","Tejada",
                  "Schmerder","Kowalkiewicz",
	              "Sauerzapf","Karg","Satsuta",
	              "Keene","Ongkowidjojo",
	              "Vayssiere","Kylau","Fenlon",
                  "Flynn","Taylor","Tan"]
                  
    generateNames(names, last_names)              
  end
  
  def generateNames(names, last_names) do
    _ = for _ <- (1..100000) do
         Enum.at(names,Enum.random(0..15)) <> " " <> Enum.at(last_names,Enum.random(0..15))
       end
    IO.puts("Done")   
  end
  
  def run_names() do
    {time, _} = :timer.tc(fn -> RandomNames.show_names end, [])
    IO.puts(time/1_000_000)
  end
end
