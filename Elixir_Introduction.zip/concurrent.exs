defmodule Concurrent do
  def proc(n)do
    :timer.sleep(3000)
    IO.puts("Process #{n}")
  end
  
  def spawn_proc(n) do
    spawn(fn -> Concurrent.proc(n) end)
  end
  
  def run_non_concurrent() do
    Enum.each(1..5, &Concurrent.proc(&1))
    Concurrent.proc("Another process")
  end
  
  def run_concurrent() do
    IO.inspect(Enum.each(1..5, &Concurrent.spawn_proc(&1)))
    Concurrent.proc("Another process")
  end  
end

#{time, _} = :timer.tc(fn -> Concurrent.run_non_concurrent end, [])
#IO.puts(time/1_000_000)

{time, _} = :timer.tc(fn -> Concurrent.run_concurrent end, [])
IO.puts(time/1_000_000)
