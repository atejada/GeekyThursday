defmodule Fibonacci do
  def fib(number) do
    fib(number, 0, 1, "")
  end
  
  def fib(1,_,_,acc) do
    IO.puts("0 1 " <> acc)
  end  
  
  def fib(number, a, b, acc) when a > 0 do
    fib(number - 1, a + b, a, acc <> to_string(a+b) <> " ") 
  end
  
  def fib(number, a, b, acc) do
    fib(number - 1, a + b, b, acc <> to_string(a+b) <> " ") 
  end
end
