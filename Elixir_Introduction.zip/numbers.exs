defmodule Numbers do
  def num(a) do
    IO.puts("This is your number #{a}")
  end

  def num(a, b) do
    IO.puts("This is the sum of two numbers #{a + b}")
  end  
end
