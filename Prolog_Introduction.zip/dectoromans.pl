number(1000,'M').
number(900,'CM').
number(500,'D').
number(400,'CD').
number(100,'C').
number(90,'XC').
number(50,'L').
number(40,'XL').
number(10,'X').
number(9,'IX').
number(5,'V').
number(4,'IV').
number(1,'I').

numbers(0,[1000,900,500,400,100,90,50,40,10,9,5,4,1]).

toRomans(_,[],[]).
toRomans(NUM, [H|T]) :- (NUM >= H -> 
                         number(H,R), write(R), 
                         X is NUM - H, 
                         (X > 0 -> numbers(0,T1), toRomans(X,T1), !; !);
                         toRomans(NUM,T)).

romans(X) :- numbers(0,L), toRomans(X,L).
