'This is a text file that we are going to read it using Prolog'.
