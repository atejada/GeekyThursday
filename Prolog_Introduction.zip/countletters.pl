main(X):- open('readme.txt',read,Str), 
          read(Str,Line), 
          X = Line,
          close(Str).

count_occurrences(List, Occ):-
    findall([X,L], (bagof(true,member(X,List),Xs), length(Xs,L)), Occ).

count_letters(Y) :- main(X), atom_chars(X,L), count_occurrences(L,Y).
