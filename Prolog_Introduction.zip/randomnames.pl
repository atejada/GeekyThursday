name(0,'Anne'). name(1,'Gigi'). name(2,'Blag'). name(3,'Juergen').
name(4,'Marek'). name(5,'Ingo'). name(6,'Lars'). name(7,'Julia').
name(8,'Danielle'). name(9,'Rocky'). name(10,'Julien'). name(11,'Uwe').
name(12,'Myles'). name(13,'Mike'). name(14,'Steven'). name(15,'Fanny').

last_name(0,"Hardy"). last_name(1,"Read"). last_name(2,"Tejada"). 
last_name(3,"Schmerder"). last_name(4,"Kowalkiewicz"). 
last_name(5,"Swauerzapf"). last_name(6,"Karg"). last_name(7,"Satsuta").
last_name(8,"Keene"). last_name(9,"Ongkowidjojo"). last_name(10,"Vayssiere").
last_name(11,"Kylau"). last_name(12,"Fenlon"). last_name(13,"Flynn").
last_name(14,"Flynn"). last_name(15,"Tan").

full_names(100000, 100000,[]).
full_names(TOP,NUM,[H|T]) :- (NUM < TOP -> 
                              X is NUM + 1,
                              random_between(0,15,L),
                              random_between(0,15,R),
                              name(L,L1),
                              last_name(R,R1),
                              H = [L1,R1],
                              full_names(TOP,X,T),!).

random_names(_) :- statistics(walltime, [_ | [_]]),
				   full_names(100000,0,_),
				   statistics(walltime, [_ | [ExecutionTime]]),
				   write('Execution took '), write(ExecutionTime), write(' ms.'), nl.
