fibo(NUM,A,B,[H|T]) :- (NUM > 1 -> H is A + B, X is NUM - 1, 
                        (A =:= 0 -> fibo(X,H,B,T); fibo(X,H,A,T))).
fibo(_,_,_,[]).

fibonacci(NUM,R) :- fibo(NUM,0,1,X), !, append([0,1], X, R).
