extern crate rand;
extern crate time;

use rand::Rng;
use time::PreciseTime;

fn main(){
	let start = PreciseTime::now();
	
	let names = vec!["Anne", "Gigi", "Blag", "Juergen", "Marek", 
	                 "Ingo", "Lars", "Julia", "Danielle", "Rocky", 
	                 "Julien", "Uwe", "Myles", "Mike", "Steven", 
	                 "Fanny"];
	let last_names = vec!["Hardy", "Read", "Tejada", "Schmerder", 
	                      "Kowalkiewicz", "Sauerzapf", "Karg", 
	                      "Satsuta", "Keene", "Ongkowidjojo", 
	                      "Vayssiere", "Kylau", "Fenlon", "Flynn", 
	                      "Taylor", "Tan"];
	
	let mut name: String = String::new();
	let mut full_names = Vec::new();
	let mut x:i64 = 0;
	
	loop{
		x = x + 1;
		name = names[rand::thread_rng().gen_range(0, 16)].to_string() + 
		       " " + last_names[rand::thread_rng().gen_range(0, 16)];
		full_names.push(name);
		if x == 1000000 {break;}
	}                      

	let end = PreciseTime::now();
	println!("Time: {}", start.to(end));
	println!("{} names generated", full_names.len());
}
