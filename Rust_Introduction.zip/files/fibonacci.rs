use std::io;

fn fib(num: i64, a: i64, b:i64) -> String{
	let mut result: String = "".to_string();
	let sum: i64 = a + b;
	let sum_str: &str = &sum.to_string();
	let a_str: &str = &a.to_string();
	let b_str: &str = &b.to_string();
	if a > 0 && num > 1 {
		result = result + sum_str + " " + &fib((num - 1), (a + b), a);
	}else if a == 0{
		result = "".to_string() + a_str + " " + b_str + " " + 
		         sum_str + " " + &fib((num - 1), (a + b), b); 
	}
	result
}

fn main(){
	println!("Enter a number : ");
	let mut input_num = String::new();
	io::stdin().read_line(&mut input_num)
	           .expect("failed to read");

	let trimmed = input_num.trim();
    match trimmed.parse::<i64>() {
        Ok(i) => { let result: String = fib(i, 0, 1); print!("{}\n", result);}
        Err(..) => println!("Please enter an interger, not {}", trimmed)
    };
}
