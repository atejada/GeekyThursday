use std::fs::File;
use std::io::BufReader;
use std::io::BufRead;
use std::collections::BTreeMap;

fn letters<'a>(line:&'a str,mut leds:BTreeMap<String, isize>){
	let letters = line.split("");
	let v: Vec<&str> = letters.collect();
	for i in v{
		*(leds.entry(i.to_string()).or_insert(0)) += 1;
	}
	for (key, value) in leds.iter() {
        println!("{} {}", key, value);
    }
}

fn main(){
	let leds: BTreeMap<String, isize> = BTreeMap::new();
	let f = File::open("readme.txt").unwrap();
	let f = BufReader::new(f);
	let mut lines = String::new();
	for line in f.lines(){
		lines = line.unwrap();
	}
	letters(&mut lines, leds);
}
