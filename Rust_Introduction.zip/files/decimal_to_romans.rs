use std::collections::HashMap;
use std::io;

fn main(){
	let mut roman_table:HashMap<&str, &str> = HashMap::new();

	roman_table.insert("1000", "M");
	roman_table.insert("900", "CM");
	roman_table.insert("500", "D");
	roman_table.insert("400", "CD");
	roman_table.insert("100", "C");
	roman_table.insert("90", "XC");
	roman_table.insert("50", "L");
	roman_table.insert("40", "XC");
	roman_table.insert("10", "X");
	roman_table.insert("9", "IX");
	roman_table.insert("5", "V");
	roman_table.insert("4", "IV");
	roman_table.insert("1", "I");

	let mut vec = Vec::new();
	
	for key in roman_table.keys(){
		match key.parse::<i64>(){
			Ok(i) => {vec.push(i);},
			Err(..) => println!("Sorry...can't make it")
		}
	}

	vec.sort_by(|a, b| b.cmp(a));
	let mut num:i64 = 0;
	let mut result: String = "".to_string();

	println!("Enter a number : ");
	let mut input_num = String::new();
	io::stdin().read_line(&mut input_num)
	           .expect("failed to read");

	let trimmed = input_num.trim();
    match trimmed.parse::<i64>() {
        Ok(i) => { num = i;}
        Err(..) => println!("Please enter an interger, not {}", trimmed)
    };

	while num > 0{
		for i in &vec{
			if &num >= i{
				match roman_table.get(&i.to_string().as_str()){
					Some(value) => {result = result + &value;
						            num = num - i;
						            },
					None => println!("")
				}
				break
			}
		}
	}

	println!("{}", result);
}
