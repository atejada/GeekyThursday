open Core.Std

let greet gender name =
	match gender with
		| "male" -> "Good Morning Mr. " ^ name
		| "female" -> "Good Morning Mrs. " ^ name
		| _ -> "Good Morning ??? " ^ name
