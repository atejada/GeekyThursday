open Core.Std

let rec show_romans num ctr =
let romans = [(1000,"M");(900,"CM");(500,"D");
              (90,"XC");(50,"L");(40,"XL");
              (10,"X");(9,"IX");(5,"V");
              (4,"IV");(1,"I")] in
		let roman = List.nth_exn romans ctr in
		if num > fst roman then snd roman ^ show_romans (num - fst roman) ctr 
		else if num < fst roman && num > 0 then show_romans num (ctr + 1)
		else "" ^ snd roman

let () =
	print_string "Enter a number: "
	let num = read_int() in
	printf "%s\n" (show_romans num 0)
