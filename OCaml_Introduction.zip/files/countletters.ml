open Core.Std
		
let rec update_list lst_count lst_file i top = 
	if i < top then
		let file_value = List.nth_exn lst_file i in 
		let value = try List.Assoc.find_exn lst_count (file_value) + 1 with Not_found -> 1 in
		let lst_count = List.Assoc.add lst_count (file_value) (value) in
		update_list lst_count lst_file (i+1) top
	else
		for i = 0 to List.length lst_count - 1 do
			let lst_value = List.nth_exn lst_count i in
			printf "%c-->%d\n" (fst lst_value) (snd lst_value)
		done

let () =
	let file = input_line ( open_in "readme.txt") in
	let lst_file = String.to_list file in
	let lst_count = [] in
	update_list lst_count lst_file 0 (List.length lst_file - 1)
