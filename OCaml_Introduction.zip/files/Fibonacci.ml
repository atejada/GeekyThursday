open Core.Std

let rec fib num a b = 
	match num with 
	| num when a > 0 && num > 1 -> string_of_int (a + b) ^ " " ^ fib (num - 1) (a+b) a
	| num when a = 0 -> string_of_int a ^ " " ^ string_of_int b ^ " " ^ 
	                    string_of_int (a + b) ^ " " ^ fib (num - 1) (a+b) b
	| num -> ""
	
let () =
	print_string "Enter a number: "
	let num = read_int() in
	printf "%s\n" (fib num 0 1)
