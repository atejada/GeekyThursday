open Core.Std

let first myTuple = 
	let (x,_,_) = myTuple in
	printf "%d" x

let second myTuple = 
	let (_,x,_) = myTuple in
	printf "%s" x
	
let third myTuple = 
	let (_,_,x) = myTuple in
	printf "%s" x	
