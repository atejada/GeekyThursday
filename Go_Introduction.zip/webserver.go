package main

import ( "io";"fmt";"html/template";"log";"net/http" )

func login(w http.ResponseWriter, r *http.Request) {
    fmt.Println("method:", r.Method)
    if r.Method == "GET" {
        t, _ := template.ParseFiles("message.gtpl")
        t.Execute(w, nil)
    } else {
        r.ParseForm()
        message := "Hello from Go, dear " + r.Form["name"][0] + "!"
        io.WriteString(w, message)
    }
}

func main() {
    http.HandleFunc("/", login)
    err := http.ListenAndServe(":8080", nil)
    if err != nil {
        log.Fatal("ListenAndServe: ", err)
    }
}
