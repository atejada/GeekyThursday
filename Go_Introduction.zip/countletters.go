package main

import ( "fmt"; "io/ioutil"; "strings" )

func main() {
    file, err := ioutil.ReadFile("readme.txt")
    if err != nil {
        fmt.Print("Couldn't open the file")
        return
    }
	str := string(file)
    str = strings.Replace(str, "\n", "", 1)
    Chars := strings.Split(str, "")
    charmap := make(map[string]int)
    for _, value := range Chars {
        charmap[value] += 1
    }
    for key, value := range charmap {
        fmt.Print("(", key, ", ")
        fmt.Println("\"", value, "\")")
    }
}
