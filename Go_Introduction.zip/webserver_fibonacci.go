package main

import ( "io";"fmt";"html/template";"log";"net/http";"strconv" )

func fibo(number int) string{
	result := "0"
	fib := 1
	first := 0
	second := 1
	i := 0
	for i < number {
		result = result + " " + strconv.Itoa(fib)
		fib = first + second
		first = second
		second = fib
		i++
	}
	return result
}

func get_fibo(w http.ResponseWriter, r *http.Request) {
    fmt.Println("method:", r.Method)
    if r.Method == "GET" {
        t, _ := template.ParseFiles("fibo.gtpl")
        t.Execute(w, nil)
    } else {
        r.ParseForm()
		number := r.Form["number"][0]
		num,_ := strconv.Atoi(number)
		result := "The Fibonacci sequence is: " + fibo(num)
		io.WriteString(w, result)
    }
}

func main() {
    http.HandleFunc("/", get_fibo)
    err := http.ListenAndServe(":8080", nil)
    if err != nil {
        log.Fatal("ListenAndServe: ", err)
    }
}
