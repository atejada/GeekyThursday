This is a text file that we're going to read it using Go
