(ns fibonacci)

(defn fib [num a b]
	(cond 
		(and (> a 0) (> num 1))
			(concat [(+ a b)] (fib (- num 1) (+ a b) a))
		(= a 0)
			(concat (conj (conj [a] b) (+ a b)) (fib (- num 1) (+ a b) b))))

(defn showFib [num]
  (fib num 0 1))
