(ns Decimal_To_Roman)

(def Romans (sorted-map-by > 1000 "M", 900 "CM", 500 "D",
                              400 "CD", 100 "C", 90 "XC",
                               50 "L", 40 "XL", 10 "X",
                                9 "IX", 5 "V", 4 "IV", 1 "I"))

(defn Get_Romans [num Romans]
	(let [roman (first(first Romans))]
		(cond
			(>= num roman)
				(apply str(concat (second (first Romans)) (Get_Romans (- num roman) Romans)))
			(and (< num roman) (> num 0))
				(Get_Romans num (rest Romans))
		)))

(defn Show_Romans [num]
	(println (Get_Romans num Romans))(symbol ""))
