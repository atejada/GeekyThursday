(ns countletters)

(def text (seq (slurp "readme.txt")))

(defn dict-inc [m word]
  (update-in m [word] (fnil inc 0)))

(defn CountLetters[]
	(reduce dict-inc {} text))
