(ns Random_Names)

(def names '["Anne" "Gigi" "Blag" "Juergen" "Marek" "Ingo" "Lars" "Julia" 
             "Danielle" "Rocky" "Julien" "Uwe" "Myles" "Mike" "Steven" "Fanny"])
             
(def last_names '["Hardy" "Read" "Tejada" "Schmerder" "Kowalkiewicz" "Sauerzapf" 
                  "Karg" "Satsuta" "Keene" "Ongkowidjojo" "Vayssiere" "Kylau" 
                  "Fenlon" "Flynn" "Taylor" "Tan"])

(defn generate_names[]
	 (concat (cons (nth names (rand-int 16)) '()) (cons (nth last_names (rand-int 16)) '())))

(defn show_names[] 
	(time (loop [i 0]
		(when (< i 100000)
			(generate_names)
			(recur (inc i))
))))


