module Main where
import Graphics.UI.WX

main :: IO ()
main = start hello

hello :: IO ()
hello = 
	do f <- frame [text := "Hello!"]
	   p <- panel f []
	   name <- textEntry p [text := ""]
	   b <- button p [text := "Greet!"]
	   l <- singleListBox p []
	   set b [on command := greet p l name]
	   set p [layout := (column 2 [
						(row 2 [fill $ widget name, widget b]),
						 fill$widget l
						 ])]
	   set f [layout := minsize (sz 300 100) $ widget p]
	where
		greet p l name = 
			do nametext <- get name text
			   let greetme = "Welcome to WxHaskell! " ++ nametext
			   set l [items := [greetme]]
