greet :: String -> String -> String
greet("male") name = "Good Morning Mr. " ++ name
greet("female") name = "Good Morning Mrs. " ++ name
greet _ name = "Good Morning ??? " ++ name