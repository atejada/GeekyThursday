import System.IO
import Data.List

main = do
    contents <- readFile "readme.txt"
    print $ numletters contents
    
letters :: String -> [String]
letters = map ((:[]))

numletters :: String -> [(String,Int)]
numletters xs = map(\ws -> (head ws, length ws)) $ 
                    group $ sort $ letters xs        
