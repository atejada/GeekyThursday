showFib :: Int -> IO()
showFib(num) = do
	--print $ fib num 0 1
	putStr $ unwords $ map show $ fib num 0 1
	putStr "\n"

fib :: Int -> Int -> Int -> [Int]
fib num a b
	| a > 0 && num > 1 = [a+b] ++ fib (num-1) (a+b) a
	| a == 0 = [a,b] ++ [a+b] ++ fib (num-1) (a+b) b
	| num == 1 = []	
